﻿namespace Lab1_Bai1
{
    partial class flab5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(flab5));
            dsDiem = new Label();
            inputDS = new TextBox();
            btXuat = new Button();
            label2 = new Label();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            label19 = new Label();
            mon1 = new Label();
            mon2 = new Label();
            mon3 = new Label();
            mon4 = new Label();
            mon5 = new Label();
            mon6 = new Label();
            mon7 = new Label();
            mon8 = new Label();
            mon9 = new Label();
            mon10 = new Label();
            mon11 = new Label();
            mon12 = new Label();
            tbinh = new Label();
            max = new Label();
            SoMonDau = new Label();
            hocluc = new Label();
            min = new Label();
            SoMonRot = new Label();
            btXoa = new Button();
            btThoat = new Button();
            SuspendLayout();
            // 
            // dsDiem
            // 
            dsDiem.AutoSize = true;
            dsDiem.BackColor = SystemColors.GradientInactiveCaption;
            dsDiem.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            dsDiem.Location = new Point(68, 66);
            dsDiem.Name = "dsDiem";
            dsDiem.Size = new Size(124, 20);
            dsDiem.TabIndex = 0;
            dsDiem.Text = "Danh sách điểm:";
            // 
            // inputDS
            // 
            inputDS.AcceptsTab = true;
            inputDS.Location = new Point(258, 59);
            inputDS.Name = "inputDS";
            inputDS.ScrollBars = ScrollBars.Vertical;
            inputDS.Size = new Size(685, 27);
            inputDS.TabIndex = 1;
            // 
            // btXuat
            // 
            btXuat.BackColor = SystemColors.ActiveCaption;
            btXuat.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btXuat.Location = new Point(803, 111);
            btXuat.Name = "btXuat";
            btXuat.Size = new Size(140, 50);
            btXuat.TabIndex = 2;
            btXuat.Text = "Xuất";
            btXuat.UseVisualStyleBackColor = false;
            btXuat.Click += btXuat_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = SystemColors.GradientInactiveCaption;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(68, 141);
            label2.Name = "label2";
            label2.Size = new Size(209, 20);
            label2.TabIndex = 3;
            label2.Text = "Danh sách môn học và điểm:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = SystemColors.GradientInactiveCaption;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label1.Location = new Point(68, 198);
            label1.Name = "label1";
            label1.Size = new Size(58, 20);
            label1.TabIndex = 4;
            label1.Text = "Môn 1:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.GradientInactiveCaption;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(740, 198);
            label3.Name = "label3";
            label3.Size = new Size(67, 20);
            label3.TabIndex = 5;
            label3.Text = "Môn 10:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = SystemColors.GradientInactiveCaption;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label4.Location = new Point(304, 198);
            label4.Name = "label4";
            label4.Size = new Size(58, 20);
            label4.TabIndex = 6;
            label4.Text = "Môn 4:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.GradientInactiveCaption;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label5.Location = new Point(740, 234);
            label5.Name = "label5";
            label5.Size = new Size(67, 20);
            label5.TabIndex = 7;
            label5.Text = "Môn 11:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = SystemColors.GradientInactiveCaption;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label6.Location = new Point(520, 198);
            label6.Name = "label6";
            label6.Size = new Size(58, 20);
            label6.TabIndex = 8;
            label6.Text = "Môn 7:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = SystemColors.GradientInactiveCaption;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label7.Location = new Point(520, 274);
            label7.Name = "label7";
            label7.Size = new Size(58, 20);
            label7.TabIndex = 9;
            label7.Text = "Môn 9:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = SystemColors.GradientInactiveCaption;
            label8.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label8.Location = new Point(520, 234);
            label8.Name = "label8";
            label8.Size = new Size(54, 20);
            label8.TabIndex = 10;
            label8.Text = "Môn 8";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = SystemColors.GradientInactiveCaption;
            label9.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label9.Location = new Point(740, 274);
            label9.Name = "label9";
            label9.Size = new Size(67, 20);
            label9.TabIndex = 11;
            label9.Text = "Môn 12:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = SystemColors.GradientInactiveCaption;
            label10.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label10.Location = new Point(304, 234);
            label10.Name = "label10";
            label10.Size = new Size(54, 20);
            label10.TabIndex = 12;
            label10.Text = "Môn 5";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = SystemColors.GradientInactiveCaption;
            label11.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label11.Location = new Point(304, 274);
            label11.Name = "label11";
            label11.Size = new Size(58, 20);
            label11.TabIndex = 13;
            label11.Text = "Môn 6:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = SystemColors.GradientInactiveCaption;
            label12.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label12.Location = new Point(68, 274);
            label12.Name = "label12";
            label12.Size = new Size(58, 20);
            label12.TabIndex = 14;
            label12.Text = "Môn 3:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = SystemColors.GradientInactiveCaption;
            label13.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label13.Location = new Point(68, 234);
            label13.Name = "label13";
            label13.Size = new Size(58, 20);
            label13.TabIndex = 15;
            label13.Text = "Môn 2:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = SystemColors.GradientInactiveCaption;
            label14.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label14.Location = new Point(68, 328);
            label14.Name = "label14";
            label14.Size = new Size(128, 20);
            label14.TabIndex = 16;
            label14.Text = "Điểm trung bình:";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = SystemColors.GradientInactiveCaption;
            label15.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label15.Location = new Point(68, 379);
            label15.Name = "label15";
            label15.Size = new Size(114, 20);
            label15.TabIndex = 17;
            label15.Text = "Điểm cao nhất:";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = SystemColors.GradientInactiveCaption;
            label16.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label16.Location = new Point(68, 433);
            label16.Name = "label16";
            label16.Size = new Size(96, 20);
            label16.TabIndex = 18;
            label16.Text = "Số môn đậu:";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = SystemColors.GradientInactiveCaption;
            label17.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label17.Location = new Point(520, 328);
            label17.Name = "label17";
            label17.Size = new Size(123, 20);
            label17.TabIndex = 19;
            label17.Text = "Xếp loại học lực:";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.BackColor = SystemColors.GradientInactiveCaption;
            label18.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label18.Location = new Point(520, 379);
            label18.Name = "label18";
            label18.Size = new Size(122, 20);
            label18.TabIndex = 20;
            label18.Text = "Điểm thấp nhất:";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = SystemColors.GradientInactiveCaption;
            label19.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label19.Location = new Point(520, 433);
            label19.Name = "label19";
            label19.Size = new Size(91, 20);
            label19.TabIndex = 21;
            label19.Text = "Số môn rớt:";
            // 
            // mon1
            // 
            mon1.AutoSize = true;
            mon1.Location = new Point(150, 198);
            mon1.Name = "mon1";
            mon1.Size = new Size(0, 20);
            mon1.TabIndex = 22;
            // 
            // mon2
            // 
            mon2.AutoSize = true;
            mon2.Location = new Point(150, 234);
            mon2.Name = "mon2";
            mon2.Size = new Size(0, 20);
            mon2.TabIndex = 23;
            // 
            // mon3
            // 
            mon3.AutoSize = true;
            mon3.Location = new Point(150, 274);
            mon3.Name = "mon3";
            mon3.Size = new Size(0, 20);
            mon3.TabIndex = 24;
            // 
            // mon4
            // 
            mon4.AutoSize = true;
            mon4.Location = new Point(386, 198);
            mon4.Name = "mon4";
            mon4.Size = new Size(0, 20);
            mon4.TabIndex = 25;
            // 
            // mon5
            // 
            mon5.AutoSize = true;
            mon5.Location = new Point(386, 234);
            mon5.Name = "mon5";
            mon5.Size = new Size(0, 20);
            mon5.TabIndex = 26;
            // 
            // mon6
            // 
            mon6.AutoSize = true;
            mon6.Location = new Point(386, 274);
            mon6.Name = "mon6";
            mon6.Size = new Size(0, 20);
            mon6.TabIndex = 27;
            // 
            // mon7
            // 
            mon7.AutoSize = true;
            mon7.Location = new Point(602, 198);
            mon7.Name = "mon7";
            mon7.Size = new Size(0, 20);
            mon7.TabIndex = 28;
            // 
            // mon8
            // 
            mon8.AutoSize = true;
            mon8.Location = new Point(602, 234);
            mon8.Name = "mon8";
            mon8.Size = new Size(0, 20);
            mon8.TabIndex = 29;
            // 
            // mon9
            // 
            mon9.AutoSize = true;
            mon9.Location = new Point(602, 274);
            mon9.Name = "mon9";
            mon9.Size = new Size(0, 20);
            mon9.TabIndex = 30;
            // 
            // mon10
            // 
            mon10.AutoSize = true;
            mon10.Location = new Point(833, 198);
            mon10.Name = "mon10";
            mon10.Size = new Size(0, 20);
            mon10.TabIndex = 31;
            // 
            // mon11
            // 
            mon11.AutoSize = true;
            mon11.Location = new Point(833, 234);
            mon11.Name = "mon11";
            mon11.Size = new Size(0, 20);
            mon11.TabIndex = 32;
            // 
            // mon12
            // 
            mon12.AutoSize = true;
            mon12.Location = new Point(833, 274);
            mon12.Name = "mon12";
            mon12.Size = new Size(0, 20);
            mon12.TabIndex = 33;
            // 
            // tbinh
            // 
            tbinh.AutoSize = true;
            tbinh.Location = new Point(232, 328);
            tbinh.Name = "tbinh";
            tbinh.Size = new Size(0, 20);
            tbinh.TabIndex = 34;
            // 
            // max
            // 
            max.AutoSize = true;
            max.Location = new Point(232, 379);
            max.Name = "max";
            max.Size = new Size(0, 20);
            max.TabIndex = 35;
            // 
            // SoMonDau
            // 
            SoMonDau.AutoSize = true;
            SoMonDau.Location = new Point(232, 433);
            SoMonDau.Name = "SoMonDau";
            SoMonDau.Size = new Size(0, 20);
            SoMonDau.TabIndex = 36;
            // 
            // hocluc
            // 
            hocluc.AutoSize = true;
            hocluc.Location = new Point(689, 328);
            hocluc.Name = "hocluc";
            hocluc.Size = new Size(0, 20);
            hocluc.TabIndex = 37;
            // 
            // min
            // 
            min.AutoSize = true;
            min.Location = new Point(689, 379);
            min.Name = "min";
            min.Size = new Size(0, 20);
            min.TabIndex = 38;
            // 
            // SoMonRot
            // 
            SoMonRot.AutoSize = true;
            SoMonRot.Location = new Point(689, 433);
            SoMonRot.Name = "SoMonRot";
            SoMonRot.Size = new Size(0, 20);
            SoMonRot.TabIndex = 39;
            // 
            // btXoa
            // 
            btXoa.BackColor = SystemColors.ActiveCaption;
            btXoa.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btXoa.Location = new Point(595, 111);
            btXoa.Name = "btXoa";
            btXoa.Size = new Size(135, 50);
            btXoa.TabIndex = 40;
            btXoa.Text = "Xóa";
            btXoa.UseVisualStyleBackColor = false;
            btXoa.Click += btXoa_Click;
            // 
            // btThoat
            // 
            btThoat.BackColor = SystemColors.ActiveCaption;
            btThoat.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            btThoat.Location = new Point(386, 111);
            btThoat.Name = "btThoat";
            btThoat.Size = new Size(135, 50);
            btThoat.TabIndex = 41;
            btThoat.Text = "Thoát";
            btThoat.UseVisualStyleBackColor = false;
            btThoat.Click += btThoat_Click;
            // 
            // flab5
            // 
            AcceptButton = btXuat;
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(973, 488);
            Controls.Add(btThoat);
            Controls.Add(btXoa);
            Controls.Add(SoMonRot);
            Controls.Add(min);
            Controls.Add(hocluc);
            Controls.Add(SoMonDau);
            Controls.Add(max);
            Controls.Add(tbinh);
            Controls.Add(mon12);
            Controls.Add(mon11);
            Controls.Add(mon10);
            Controls.Add(mon9);
            Controls.Add(mon8);
            Controls.Add(mon7);
            Controls.Add(mon6);
            Controls.Add(mon5);
            Controls.Add(mon4);
            Controls.Add(mon3);
            Controls.Add(mon2);
            Controls.Add(mon1);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(btXuat);
            Controls.Add(inputDS);
            Controls.Add(dsDiem);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "flab5";
            Text = "Lab1_Bai5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label dsDiem;
        private TextBox inputDS;
        private Button btXuat;
        private Label label2;
        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
        private Label label19;
        private Label mon1;
        private Label mon2;
        private Label mon3;
        private Label mon4;
        private Label mon5;
        private Label mon6;
        private Label mon7;
        private Label mon8;
        private Label mon9;
        private Label mon10;
        private Label mon11;
        private Label mon12;
        private Label tbinh;
        private Label max;
        private Label SoMonDau;
        private Label hocluc;
        private Label min;
        private Label SoMonRot;
        private Button btXoa;
        private Button btThoat;
    }
}